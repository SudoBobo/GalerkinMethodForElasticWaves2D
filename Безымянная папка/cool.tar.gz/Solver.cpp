//#include "Solver.h"

//Solver::Solver(SystemMaker systemMaker, SystemSolver systemSolver,
//			   std::vector <triangle> mesh, double fullTime, double timeStep)
//{

//}

//Solver::solve()
//{
//	m_systemSolver->calcNextState(m_origState, m_newState);
//	m_origState = m_newState;
//	// write somehow
//}
