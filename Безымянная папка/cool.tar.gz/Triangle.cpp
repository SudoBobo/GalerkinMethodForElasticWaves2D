#include "Triangle.h"
#include <iostream>

Triangle::Triangle (int polynomialOrder, int uSize, double lambda, double mu, double rho,
		  std::array <double, 3> x, std::array <double, 3> y,
		  std::array <double, 3> z):
	polynomialOrder(polynomialOrder), uSize(uSize),
	x(x), y(y), z(z), A(uSize, uSize), B(uSize, uSize), U(uSize, 1)
{

	//checked

	A(3, 0) = -(1/rho);
	A(4, 2) = -(1/rho);
	A(0, 3) = -(lambda + 2 * mu);
	A(1, 3) = -lambda;
	A(2, 4) = -mu;

	B(4, 1) = -(1/rho);
	B(3, 2) = -(1/rho);
	B(2, 3) = -mu;
	B(1, 4) = -(lambda + 2 * mu);
	B(0, 4) = -lambda;

	std::cout << "A = " << A << std::endl;
	std::cout << "B = " << B << std::endl;

	//checked
}


Triangle::Triangle (int polynomialOrder, int uSize, double lambda, double mu,
		  double rho):
	polynomialOrder(polynomialOrder), uSize(uSize),
	A(uSize, uSize), B(uSize, uSize), U(uSize, 1)
{
	A(3, 0) = -(1/rho);
	A(4, 2) = -(1/rho);
	A(0, 3) = -(lambda + 2 * mu);
	A(1, 3) = -lambda;
	A(2, 4) = -mu;

	B(4, 1) = -(1/rho);
	B(3, 2) = -(1/rho);
	B(2, 3) = -mu;
	B(1, 4) = -(lambda + 2 * mu);
	B(0, 4) = -lambda;
}



void Triangle::setFirstBoundaryTriangle (Triangle * triangle)
{
	static int numberOfCalls = 0;
	if (numberOfCalls != 0)
		std::range_error("an attempt to change boundaryTriangle1");
	numberOfCalls++;

	if (triangle == nullptr)
		throw std::range_error("an attempt to assign nullptr!");
	firstBoundaryTriangle = triangle;
}

void Triangle::setSecondBoundaryTriangle (Triangle * triangle)
{
	static int numberOfCalls = 0;
	if (numberOfCalls != 0)
		std::range_error("an attempt to change boundaryTriangle2");
	numberOfCalls++;

	if (triangle == nullptr)
		throw std::range_error("an attempt to assign nullptr!");
	secondBoundaryTriangle = triangle;
}

void Triangle::setThirdBoundaryTriangle (Triangle * triangle)
{
	static int numberOfCalls = 0;
	if (numberOfCalls != 0)
		std::range_error("an attempt to change boundaryTriangle3");
	numberOfCalls++;

	if (triangle == nullptr)
		throw std::range_error("an attempt to assign nullptr!");
	thirdBoundaryTriangle = triangle;
}

void Triangle::setVertexCoordinateX (std::array <double, 3> x)
{
	this->x = x;
}

void Triangle::setVertexCoordinateY (std::array <double, 3> y)
{
	this->y = y;
}

matrix <double> Triangle::getA() const
{
	return A;
}

matrix <double> Triangle::getB() const
{
	return B;
}

void Triangle::setNumber(int number)
{
	this->number = number;
}

void Triangle::setNumberInRectangle(int number)
{
	this->numberInRectangle = number;
}


int Triangle::getNumber() const
{
	return number;
}
int Triangle::getNumberInRectangle() const
{
	return numberInRectangle;
}

void Triangle::setRectangleN(int N)
{
	this->rectangleN = N;
}

void Triangle::setRectangleM(int M)
{
	this->rectangleM = M;
}

int Triangle::getRectangleN() const
{
	return rectangleN;
}

int Triangle::getRectangleM() const
{
	return rectangleM;
}

Triangle * Triangle::getFirstBoundaryTriangle() const
{
	return firstBoundaryTriangle;
}

Triangle * Triangle::getSecondBoundaryTriangle() const
{
	return secondBoundaryTriangle;
}


Triangle * Triangle::getThirdBoundaryTriangle() const
{
	return thirdBoundaryTriangle;
}


void Triangle::writeBoundaries() const
{
	std::cout << "m = " << number << "  m1 =" <<
				 firstBoundaryTriangle->getNumber() << "  m2 =" <<
				 secondBoundaryTriangle->getNumber( ) << "  m3 =" <<
				 thirdBoundaryTriangle->getNumber() << std::endl;
}

