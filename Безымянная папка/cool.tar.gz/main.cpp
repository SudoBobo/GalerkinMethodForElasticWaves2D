#include <iostream>
#include <cmath>
#include <Triangle.h>
#include <Support.h>
#include <iomanip>



int main()
{
	// full time
	double T = 100 * std::sqrt(2.0);
	double timeStep = 1;
	// omega (rectangle sizes)
	double xSize  = 100;
	double ySize  = 100;
	double spatialStep = 25;
	double lambda = 2;
	double mu     = 1;
	double rho    = 1;
	int polynomialOrder = 2;
	int uSize = 5;
	std::array <double, 3> x = {1,2,3};
	std::array <double, 3> y = {4,5,6};
	std::array <double, 3> z = {7,8,9};
	Triangle t(polynomialOrder, 5, lambda, mu, rho, x, y, z);

	std::vector <Triangle> mesh = createRegularTriangelMesh(xSize, ySize,
															spatialStep,
															lambda, mu, rho,
															polynomialOrder,
															uSize);
//															simpleInitialState);

//	Solver solver(galerkinSystemMaker, eulerSystemSolver, mesh, T, timeStep);
//	solver.solve();
	std::cout << std::fixed << std::endl;
	std::cout.precision(1);
	std::cout << "rectangles = " << mesh.size() << std::endl;
	for (auto it = mesh.begin(); it < mesh.end(); it++)
	{
		it->writeBoundaries();
//		std::cout << "A = " << it->getA() << std::endl;
//		std::cout << "B = " << it->getB() << std::endl;
	}
	return 0;
}

