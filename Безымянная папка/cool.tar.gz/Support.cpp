#include <Support.h>
#include <exception>
#include <cmath>

std::vector <Triangle> createRegularTriangelMesh(double xSize, double ySize,
												 double spatialStep,
												 double lambda, double mu,
												 double rho,
												 int polynomialOrder,
												 int uSize)
{
	if ((xSize < spatialStep) || (ySize < spatialStep))
		throw std::range_error("xSize or ySize is less than spatialStep");

	const double fullSquare = xSize * ySize;
	const double rectangleSquare = spatialStep * spatialStep;
	// one rectangle -> four triangles




	if (std::fmod(fullSquare,rectangleSquare) != 0)
		throw std::range_error("fullSquare % rectangelSquare != 0");

	const int numberOfRectangles = fullSquare / rectangleSquare;

	if(xSize != ySize)
		throw std::range_error("Only squre case is implemented");

	const int Nmax = (xSize / spatialStep) - 1;
	const int Mmax = (ySize / spatialStep) - 1;

	const int numberOfTriangles = 4 * numberOfRectangles;
	//забахать туда простой конструктор
	std::vector <Triangle> mesh (numberOfTriangles, Triangle(polynomialOrder,
															  uSize, lambda, mu,
															  rho ));
	int numberInRectangle = 0;
	int M = 0;
	int N = 0;

	for (int m = 0; m < mesh.size(); m++)
	{
		mesh[m].setNumber(m);
		mesh[m].setNumberInRectangle(numberInRectangle);
		numberInRectangle++;

		mesh[m].setRectangleN(N);


		if (numberInRectangle == 4)
		{
				numberInRectangle = 0;
				N++;
		}

		mesh[m].setRectangleM(M);

		if(Nmax < N)
		{
			N = 0;
			M++;
		}

	}

	for (int m = 0; m < mesh.size(); m++)
	{

		static int M;
		static int N;

		M = mesh[m].getRectangleM();
		N = mesh[m].getRectangleN();

			switch (mesh[m].getNumberInRectangle())
			 {
				 case 0:
					 {
						mesh[m].setFirstBoundaryTriangle (&mesh[m+1]);
						mesh[m].setSecondBoundaryTriangle(&mesh[m+3]);
						if (N == 0)
							mesh[m].setThirdBoundaryTriangle(&mesh[m+Nmax*4+2]);
						else
							mesh[m].setThirdBoundaryTriangle (&mesh[m-2]);
						break;
					 }
				 case 1:
					 {
						mesh[m].setFirstBoundaryTriangle (&mesh[m-1]);
						mesh[m].setSecondBoundaryTriangle(&mesh[m+1]);
						if (M == Mmax)
							mesh[m].setThirdBoundaryTriangle (&mesh[m-Mmax*4-2]);
						else
							mesh[m].setThirdBoundaryTriangle (&mesh[m+3+(Nmax+1)*4-1]);
						break;
					 }

				case 2:
					{
						mesh[m].setFirstBoundaryTriangle (&mesh[m-1]);
						mesh[m].setSecondBoundaryTriangle(&mesh[m+1]);
						if (N == Nmax)
							mesh[m].setThirdBoundaryTriangle (&mesh[m-Nmax*4-2]);
						else
							mesh[m].setThirdBoundaryTriangle (&mesh[m+2]);
						break;
					}

				case 3:
					{
						mesh[m].setFirstBoundaryTriangle (&mesh[m-3]);
						mesh[m].setSecondBoundaryTriangle(&mesh[m-1]);
						if (M == 0)
							mesh[m].setThirdBoundaryTriangle (&mesh[m+Mmax*4+2]);
						else
							mesh[m].setThirdBoundaryTriangle (&mesh[m-(3+(Nmax+1)*4-1)]);
						break;
					}

			 }
		}

	return mesh;
}
