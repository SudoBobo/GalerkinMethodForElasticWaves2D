#ifndef SUPPORT
#define SUPPORT

#include <Triangle.h>

std::vector <Triangle> createRegularTriangelMesh(double xSize, double ySize,
												 double spatialStep,
												 double lambda, double mu,
												 double rho,
												 int polynomialOrder,
												 int uSize);
#endif // SUPPORT

