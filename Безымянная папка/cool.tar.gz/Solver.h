//#ifndef SOLVER_H
//#define SOLVER_H


//class Solver
//{
//public:
//	Solver();

//signals:

//public slots:
//};

//#endif // SOLVER_H
